clear all;
close all;
clc;
file=importdata('cal_sim.log');
%temp = cell2mat(out);

infor_shift = 0;
error = file(:,infor_shift+3);%%temp = cell2mat(lccddata(2));
left = file(:,infor_shift+1);
right = file(:,infor_shift+2);
stervo_agnle = file(:,infor_shift+4);


subplot(2,2,1);
title('��������');
plot(error);
subplot(2,2,2);
plot(left);
subplot(2,2,3);
plot(right);
subplot(2,2,4);
plot(stervo_agnle);

figure(2);
plot(left,'red');
hold on;
plot(right,'blue');
hold on;
plot(error,'black');
hold on;
plot(stervo_agnle,'green');
legend('left','right','error');
xlabel('n');
ylabel('x');
title('�߽缰���');
grid on;


